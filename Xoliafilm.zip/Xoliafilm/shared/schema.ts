import { pgTable, text, serial, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const movies = pgTable("movies", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  year: integer("year").notNull(),
  genre: text("genre").notNull(),
  videoUrl: text("video_url").notNull(),
  views: integer("views").notNull().default(0),
});

export const insertMovieSchema = createInsertSchema(movies).omit({ id: true, views: true });

export type Movie = typeof movies.$inferSelect;
export type InsertMovie = z.infer<typeof insertMovieSchema>;
