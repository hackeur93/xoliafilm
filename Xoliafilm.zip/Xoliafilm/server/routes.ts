import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

async function seedDatabase() {
  const existing = await storage.getMovies();
  if (existing.length === 0) {
    await storage.createMovie({
      title: "Big Buck Bunny",
      description: "A large and lovable rabbit deals with three tiny bullies, led by a flying squirrel, who are determined to squelch his happiness.",
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Big_buck_bunny_poster_big.jpg/800px-Big_buck_bunny_poster_big.jpg",
      year: 2008,
      genre: "Animation",
      videoUrl: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    });
    await storage.createMovie({
      title: "Sintel",
      description: "A lonely young woman, Sintel, helps and befriends a dragon, whom she calls Scales. But when he is kidnapped by an adult dragon, Sintel decides to embark on a dangerous quest to find her lost friend.",
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Sintel_poster.jpg/800px-Sintel_poster.jpg",
      year: 2010,
      genre: "Fantasy",
      videoUrl: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    });
    await storage.createMovie({
      title: "Tears of Steel",
      description: "In a dystopian future, a group of warriors and scientists attempt to save the world from alien robots.",
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Tears_of_Steel_poster.jpg/800px-Tears_of_Steel_poster.jpg",
      year: 2012,
      genre: "Sci-Fi",
      videoUrl: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    });
    await storage.createMovie({
      title: "Cosmos Laundromat",
      description: "On a desolate island, a suicidal sheep named Franck meets a quirky salesman, who offers him a gift that will change his life.",
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Cosmos_Laundromat_-_Poster.jpg/800px-Cosmos_Laundromat_-_Poster.jpg",
      year: 2015,
      genre: "Animation",
      videoUrl: "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    });
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Seed data on startup
  seedDatabase();

  app.get(api.movies.list.path, async (req, res) => {
    const movies = await storage.getMovies();
    res.json(movies);
  });

  app.get(api.movies.get.path, async (req, res) => {
    const movie = await storage.getMovie(Number(req.params.id));
    if (!movie) {
      return res.status(404).json({ message: 'Movie not found' });
    }
    res.json(movie);
  });

  app.post(api.movies.create.path, async (req, res) => {
    try {
      const input = api.movies.create.input.parse(req.body);
      const movie = await storage.createMovie(input);
      res.status(201).json(movie);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
        });
      }
      throw err;
    }
  });

  app.delete(api.movies.delete.path, async (req, res) => {
    await storage.deleteMovie(Number(req.params.id));
    res.status(204).send();
  });

  return httpServer;
}
