import { type Movie, type InsertMovie } from "@shared/schema";

export interface IStorage {
  getMovies(): Promise<Movie[]>;
  getMovie(id: number): Promise<Movie | undefined>;
  createMovie(movie: InsertMovie): Promise<Movie>;
  deleteMovie(id: number): Promise<void>;
  incrementViews(id: number): Promise<Movie | undefined>;
}

export class MemStorage implements IStorage {
  private movies: Map<number, Movie>;
  private currentId: number;

  constructor() {
    this.movies = new Map();
    this.currentId = 1;
  }

  async getMovies(): Promise<Movie[]> {
    return Array.from(this.movies.values());
  }

  async getMovie(id: number): Promise<Movie | undefined> {
    return this.movies.get(id);
  }

  async createMovie(insertMovie: InsertMovie): Promise<Movie> {
    const id = this.currentId++;
    const movie: Movie = { ...insertMovie, id, views: 0 };
    this.movies.set(id, movie);
    return movie;
  }

  async deleteMovie(id: number): Promise<void> {
    this.movies.delete(id);
  }

  async incrementViews(id: number): Promise<Movie | undefined> {
    const movie = this.movies.get(id);
    if (movie) {
      const updated = { ...movie, views: (movie.views || 0) + 1 };
      this.movies.set(id, updated);
      return updated;
    }
    return undefined;
  }
}

export const storage = new MemStorage();
