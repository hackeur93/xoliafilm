import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMovieSchema, type InsertMovie } from "@shared/schema";
import { useCreateMovie, useDeleteMovie, useMovies } from "@/hooks/use-movies";
import { Loader2, Trash2, Plus, Film, LogOut } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link, useLocation } from "wouter";

// Simple admin auth check
function AdminLogin({ onLogin }: { onLogin: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "admin123") {
      onLogin();
    } else {
      setError(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#141414] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-black/50 border border-gray-800 p-8 rounded-2xl shadow-2xl backdrop-blur-sm">
        <h2 className="text-3xl font-display text-primary mb-6 text-center">Admin Access</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(false); }}
              className="w-full bg-[#333] border border-transparent rounded px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary placeholder-gray-500"
              placeholder="Enter admin password"
            />
            {error && <p className="text-red-500 text-sm mt-2">Incorrect password.</p>}
          </div>
          <button
            type="submit"
            className="w-full bg-primary hover:bg-red-700 text-white font-bold py-3 rounded transition-colors"
          >
            Sign In
          </button>
        </form>
        <div className="mt-6 text-center">
          <Link href="/">
            <a className="text-gray-500 hover:text-white text-sm">Return to Home</a>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const { data: movies, isLoading: isLoadingMovies } = useMovies();
  const createMovie = useCreateMovie();
  const deleteMovie = useDeleteMovie();
  const { toast } = useToast();
  const [location, setLocation] = useLocation();

  const form = useForm<InsertMovie>({
    resolver: zodResolver(insertMovieSchema),
    defaultValues: {
      title: "",
      description: "",
      year: new Date().getFullYear(),
      genre: "Action",
      imageUrl: "",
      videoUrl: "",
    },
  });

  const onSubmit = async (data: InsertMovie) => {
    try {
      await createMovie.mutateAsync(data);
      toast({
        title: "Success",
        description: "Movie added to the catalog.",
      });
      form.reset();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create movie",
      });
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this movie?")) return;
    try {
      await deleteMovie.mutateAsync(id);
      toast({
        title: "Deleted",
        description: "Movie removed from catalog.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete movie",
      });
    }
  };

  if (!isAuthenticated) {
    return <AdminLogin onLogin={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="min-h-screen bg-[#141414] text-white p-6 md:p-12 font-sans">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-12">
          <div className="flex items-center gap-4">
            <h1 className="text-4xl font-display text-white">Dashboard</h1>
            <span className="bg-primary/20 text-primary px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Admin</span>
          </div>
          <button 
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition"
          >
            <LogOut className="w-5 h-5" />
            Exit Admin
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Add Movie Form */}
          <div className="bg-card rounded-xl p-8 border border-border/50 shadow-xl h-fit">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Plus className="w-6 h-6 text-primary" /> Add New Movie
            </h2>
            
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Title</label>
                  <input
                    {...form.register("title")}
                    className="w-full bg-[#222] border border-gray-700 rounded p-3 focus:border-primary focus:outline-none transition-colors"
                    placeholder="Inception"
                  />
                  {form.formState.errors.title && <p className="text-red-500 text-xs">{form.formState.errors.title.message}</p>}
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300">Year</label>
                  <input
                    type="number"
                    {...form.register("year", { valueAsNumber: true })}
                    className="w-full bg-[#222] border border-gray-700 rounded p-3 focus:border-primary focus:outline-none transition-colors"
                  />
                  {form.formState.errors.year && <p className="text-red-500 text-xs">{form.formState.errors.year.message}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Genre</label>
                <input
                  {...form.register("genre")}
                  className="w-full bg-[#222] border border-gray-700 rounded p-3 focus:border-primary focus:outline-none transition-colors"
                  placeholder="Sci-Fi, Action, Thriller"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Description</label>
                <textarea
                  {...form.register("description")}
                  rows={4}
                  className="w-full bg-[#222] border border-gray-700 rounded p-3 focus:border-primary focus:outline-none transition-colors resize-none"
                  placeholder="Movie synopsis..."
                />
                {form.formState.errors.description && <p className="text-red-500 text-xs">{form.formState.errors.description.message}</p>}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Image URL (Poster)</label>
                <input
                  {...form.register("imageUrl")}
                  className="w-full bg-[#222] border border-gray-700 rounded p-3 focus:border-primary focus:outline-none transition-colors"
                  placeholder="https://images.unsplash.com/..."
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Video Embed URL</label>
                <input
                  {...form.register("videoUrl")}
                  className="w-full bg-[#222] border border-gray-700 rounded p-3 focus:border-primary focus:outline-none transition-colors"
                  placeholder="https://www.youtube.com/embed/..."
                />
              </div>

              <button
                type="submit"
                disabled={createMovie.isPending}
                className="w-full bg-primary hover:bg-red-700 disabled:opacity-50 text-white font-bold py-4 rounded transition-all shadow-lg hover:shadow-red-900/20"
              >
                {createMovie.isPending ? <Loader2 className="animate-spin mx-auto" /> : "Add Movie to Catalog"}
              </button>
            </form>
          </div>

          {/* Movie List */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Film className="w-6 h-6 text-primary" /> Current Catalog
            </h2>
            
            {isLoadingMovies ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="grid gap-4 max-h-[800px] overflow-y-auto pr-2 custom-scrollbar">
                {movies?.map((movie) => (
                  <div key={movie.id} className="group flex gap-4 bg-[#1a1a1a] p-3 rounded-lg border border-transparent hover:border-gray-700 transition-colors items-start">
                    <img src={movie.imageUrl} alt={movie.title} className="w-20 h-28 object-cover rounded bg-gray-800" />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-lg truncate">{movie.title}</h3>
                      <div className="text-sm text-gray-400 mb-2">{movie.year} • {movie.genre}</div>
                      <p className="text-xs text-gray-500 line-clamp-2">{movie.description}</p>
                    </div>
                    <button
                      onClick={() => handleDelete(movie.id)}
                      disabled={deleteMovie.isPending}
                      className="p-2 text-gray-500 hover:text-red-500 hover:bg-red-500/10 rounded transition-colors self-center"
                      title="Delete Movie"
                    >
                      {deleteMovie.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Trash2 className="w-5 h-5" />}
                    </button>
                  </div>
                ))}
                
                {movies?.length === 0 && (
                  <div className="text-center py-12 text-gray-500 border-2 border-dashed border-gray-800 rounded-lg">
                    No movies in catalog yet.
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
