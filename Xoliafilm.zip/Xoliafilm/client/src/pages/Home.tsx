import { useMovies } from "@/hooks/use-movies";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { MovieCard } from "@/components/MovieCard";
import { Loader2 } from "lucide-react";

export default function Home() {
  const { data: movies, isLoading, error } = useMovies();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#141414] flex items-center justify-center text-white">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#141414] flex items-center justify-center text-red-500">
        Failed to load movies.
      </div>
    );
  }

  const featuredMovie = movies && movies.length > 0 ? movies[0] : undefined;
  const trendingMovies = movies || [];
  const actionMovies = movies?.filter(m => m.genre.toLowerCase().includes("action")) || [];

  return (
    <div className="min-h-screen bg-[#141414] text-white font-sans overflow-x-hidden">
      <Navbar />
      
      <Hero movie={featuredMovie} />
      
      <div className="relative z-10 -mt-32 pb-20 space-y-12 pl-4 md:pl-12">
        <section>
          <h2 className="text-xl md:text-2xl font-bold mb-4 text-white/90">Trending Now</h2>
          <div className="flex gap-4 overflow-x-auto pb-8 pt-4 px-2 no-scrollbar mask-gradient">
            {trendingMovies.map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        </section>

        {actionMovies.length > 0 && (
          <section>
            <h2 className="text-xl md:text-2xl font-bold mb-4 text-white/90">Action Thrillers</h2>
            <div className="flex gap-4 overflow-x-auto pb-8 pt-4 px-2 no-scrollbar">
              {actionMovies.map((movie) => (
                <MovieCard key={movie.id} movie={movie} />
              ))}
            </div>
          </section>
        )}
        
        <section>
          <h2 className="text-xl md:text-2xl font-bold mb-4 text-white/90">New Releases</h2>
          <div className="flex gap-4 overflow-x-auto pb-8 pt-4 px-2 no-scrollbar">
            {/* Just reusing trending for demo purposes if list is short */}
            {[...trendingMovies].reverse().map((movie) => (
              <MovieCard key={`rev-${movie.id}`} movie={movie} />
            ))}
          </div>
        </section>
      </div>

      <footer className="py-12 px-4 md:px-12 text-center text-gray-500 text-sm bg-black/20">
        <p>&copy; 2024 Ma Plateforme. All rights reserved.</p>
        <div className="mt-4 flex justify-center gap-6">
          <span className="hover:underline cursor-pointer">Terms of Use</span>
          <span className="hover:underline cursor-pointer">Privacy</span>
          <span className="hover:underline cursor-pointer">Cookie Preferences</span>
        </div>
      </footer>
    </div>
  );
}
