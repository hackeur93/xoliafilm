import { useRoute, Link } from "wouter";
import { useMovie } from "@/hooks/use-movies";
import { ArrowLeft, Loader2, Calendar, Film } from "lucide-react";
import { Navbar } from "@/components/Navbar";

export default function Watch() {
  const [, params] = useRoute("/watch/:id");
  const id = params ? parseInt(params.id) : 0;
  const { data: movie, isLoading, error } = useMovie(id);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#141414] flex items-center justify-center text-primary">
        <Loader2 className="w-12 h-12 animate-spin" />
      </div>
    );
  }

  if (error || !movie) {
    return (
      <div className="min-h-screen bg-[#141414] flex flex-col items-center justify-center text-white gap-4">
        <p className="text-xl text-red-500">Movie not found</p>
        <Link href="/">
          <a className="bg-white/10 px-6 py-2 rounded hover:bg-white/20 transition">Go Home</a>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#141414] text-white">
      <Navbar />

      <div className="pt-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link href="/">
          <div className="inline-flex items-center gap-2 mb-6 text-gray-400 hover:text-white transition cursor-pointer group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span>Back to Browse</span>
          </div>
        </Link>

        {/* Video Player Container */}
        <div className="w-full aspect-video bg-black rounded-xl overflow-hidden shadow-2xl border border-gray-800 relative group">
          <iframe 
            src={movie.videoUrl} 
            title={movie.title}
            className="w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>

        {/* Movie Info */}
        <div className="mt-8 mb-20 max-w-4xl">
          <h1 className="text-4xl md:text-6xl font-display mb-4">{movie.title}</h1>
          
          <div className="flex items-center gap-6 mb-6 text-sm md:text-base text-gray-300">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" />
              <span>{movie.year}</span>
            </div>
            <div className="flex items-center gap-2">
              <Film className="w-4 h-4 text-primary" />
              <span className="uppercase tracking-wide">{movie.genre}</span>
            </div>
          </div>
          
          <p className="text-lg text-gray-300 leading-relaxed">
            {movie.description}
          </p>
        </div>
      </div>
    </div>
  );
}
