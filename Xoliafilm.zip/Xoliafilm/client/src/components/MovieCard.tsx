import { Movie } from "@shared/schema";
import { Link } from "wouter";
import { PlayCircle } from "lucide-react";
import { motion } from "framer-motion";

interface MovieCardProps {
  movie: Movie;
}

export function MovieCard({ movie }: MovieCardProps) {
  return (
    <Link href={`/watch/${movie.id}`}>
      <motion.div 
        className="group relative flex-none w-[160px] md:w-[240px] aspect-[2/3] rounded-md overflow-hidden cursor-pointer bg-zinc-800"
        whileHover={{ scale: 1.05, zIndex: 10 }}
        transition={{ duration: 0.3 }}
      >
        <img 
          src={movie.imageUrl} 
          alt={movie.title}
          className="w-full h-full object-cover transition-opacity duration-300 group-hover:opacity-60"
          loading="lazy"
        />
        
        <div className="absolute inset-0 flex flex-col justify-end p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-t from-black/90 to-transparent">
          <PlayCircle className="w-10 h-10 text-white mx-auto mb-4 drop-shadow-lg scale-0 group-hover:scale-100 transition-transform duration-300" />
          <h3 className="text-white font-bold text-sm md:text-base leading-tight drop-shadow-md">
            {movie.title}
          </h3>
          <div className="flex items-center gap-2 mt-1 text-[10px] md:text-xs text-green-400 font-semibold">
            <span>{movie.year}</span>
            <span className="w-1 h-1 rounded-full bg-gray-400"></span>
            <span className="text-gray-300 border border-gray-500 px-1 rounded uppercase">{movie.genre}</span>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
