import { Movie } from "@shared/schema";
import { Link } from "wouter";
import { Play, Info } from "lucide-react";
import { motion } from "framer-motion";

interface HeroProps {
  movie?: Movie;
}

export function Hero({ movie }: HeroProps) {
  if (!movie) return null;

  return (
    <div className="relative h-[85vh] w-full overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img 
          src={movie.imageUrl} 
          alt={movie.title}
          className="w-full h-full object-cover object-top"
        />
        <div className="hero-gradient absolute inset-0"></div>
      </div>

      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center pt-20">
        <div className="max-w-2xl space-y-6">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-7xl font-display text-white drop-shadow-xl"
          >
            {movie.title}
          </motion.h1>
          
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="flex items-center gap-4 text-white/90 text-sm md:text-base font-semibold"
          >
            <span className="text-green-500">98% Match</span>
            <span>{movie.year}</span>
            <span className="border border-white/40 px-2 py-0.5 rounded text-xs">HD</span>
            <span>{movie.genre}</span>
          </motion.div>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="text-white/80 text-lg md:text-xl line-clamp-3 md:line-clamp-4 max-w-xl text-shadow"
          >
            {movie.description}
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.8 }}
            className="flex items-center gap-4 pt-4"
          >
            <Link href={`/watch/${movie.id}`}>
              <button className="flex items-center gap-2 bg-white text-black px-8 py-3 rounded hover:bg-white/90 transition-colors font-bold text-lg">
                <Play className="w-6 h-6 fill-black" />
                Play
              </button>
            </Link>
            <button className="flex items-center gap-2 bg-gray-500/40 backdrop-blur-md text-white px-8 py-3 rounded hover:bg-gray-500/50 transition-colors font-bold text-lg">
              <Info className="w-6 h-6" />
              More Info
            </button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
