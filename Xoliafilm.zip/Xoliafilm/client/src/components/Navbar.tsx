import { Link, useLocation } from "wouter";
import { Search, User } from "lucide-react";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled ? "bg-[#141414]/95 backdrop-blur-sm shadow-md" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <div className="flex items-center gap-8">
            <Link href="/" className="cursor-pointer">
              <span className="text-3xl md:text-4xl font-display text-primary tracking-widest hover:scale-105 transition-transform">
                MA PLATEFORME
              </span>
            </Link>
            
            <div className="hidden md:flex gap-6 text-sm font-medium text-gray-300">
              <Link href="/" className="hover:text-white transition-colors cursor-pointer">Home</Link>
              <Link href="/" className="hover:text-white transition-colors cursor-pointer">TV Shows</Link>
              <Link href="/" className="hover:text-white transition-colors cursor-pointer">Movies</Link>
              <Link href="/" className="hover:text-white transition-colors cursor-pointer">New & Popular</Link>
            </div>
          </div>

          <div className="flex items-center gap-4 text-white">
            <div className="relative group hidden sm:block">
              <Search className="w-5 h-5 cursor-pointer hover:text-gray-300" />
            </div>
            
            <Link href="/admin" className="cursor-pointer">
              <div className="flex items-center gap-2 hover:bg-white/10 p-2 rounded-full transition-colors">
                <User className="w-5 h-5" />
                {location.startsWith("/admin") && <span className="text-xs font-bold">ADMIN</span>}
              </div>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
